Samantha Ray - linkedin.com/in/samantharay
kevin Candau -linkedin.com/in/kevincandau
vibranium-1211 -> SWE III - 
Amanda Eller -linkedin.com/in/amanda-eller-3045206b
Chris Dalla Santa-linkedin.com/in/chris-dalla-santa
DocuCode Technical Workshop - Docusign



Behaviour

Technical interview - Ask Questions
Given two objects, determine if they are equal

1 Test
Communication
-Start coding and talk through it
-dont be afraid to ask questions, prove you are teachable is great
-Testing is key, you might get follow up questions
    -how would you test this? -More answers to this is rarely a bad thing
    -What is the time complexity? Could you make it more efficient?
        -Know your Big O notation
        -There is not always an answer to "could you make it more efficient, but talking through ideas is the point, talk through your code and calculate/talk about what the bigO notation of each function, or part of the code is
    -How would you change your method if we did not statically type the objects?(or other change the "prompt" questions)
        -This can prove that you wrote and understand your code, you didn't copy it.
-Two objects are similar
"Design an elevator and everything that would creating into it"
-Everytime you fail an interview, it prepares you towards successful
-Alot of learning comes from peer programming
-Don't be afraid to ask for help, and their approach
-Should always have a "Yes" if they ask if you have any questions for them.
    -Is there a cultural that 
    -how did your company handle covid? Supportive? Strict? WFH?
    -What are some of the projects you or your team are working on?
    -Whats the mngr like?
    -Whats the team culture?
-They want you to be THAT candidate that they've been looking for. They want you to succeed. ~they also want to stop interviewing lol
-Language rarely matters, unless they NEED a go dev
    -its easier to learn a new language
    -hard to learn how to teach how to code
    -They want you at your best, Use your best language, usually doesn't matter
-How indepth into DS&A should we go into?
    -medium difficulty on leetcode
    -Harder than easy, but rarely hard
    -having a base level understanding will help prepare you for real questions
-When testing or trying to solve problems
    -brute force
    -attempt
    -make it better, show it
-Can ask the interview if its ok to start in pseudocode, but could get an in person wheere you're on a whiteboard